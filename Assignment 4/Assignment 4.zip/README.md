### The files for Assignment 4 is in the repository.

### The input of the step function should be a json object such as 
    `{
        "name": "kevin",
        "email": "zhengkaiw851@gmail.com",
        "course": [
            "WebTool"
        ]
    }`